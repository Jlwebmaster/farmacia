<?php
require_once ("vistas/encabezado.php")
?>

<!--aqui empieza la parte principal de la pagina-->

 <div class="container">
   
 </div>

<!--aqui empieza el pie de la pagina-->

 <?php
require_once ("vistas/pie.php")
?>