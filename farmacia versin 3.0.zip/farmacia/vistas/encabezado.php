<?php
?>
<!DOCTYPE html>
<html lang="esp">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta http-equiv="X-UA-Compatible" content="ie=edge">

<title>s.g.f cronosth</title>

  <link rel="stylesheet" href="assets/css/maicons.css">

  <link rel="stylesheet" href="assets/css/bootstrap.css">

  <link rel="stylesheet" href="assets/vendor/owl-carousel/css/owl.carousel.css">

  <link rel="stylesheet" href="assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="assets/css/theme.css">
 
  
  
</head>
<body>

  <!-- Back to top button -->
 
<style>
  #datos{
    color:aqua;
  }
</style>
  <header>
    <div class="topbar">
      <div class="container">
        <div class="row">
          <div class="col-sm-8 text-sm">
            <div class="site-info">
              <a href="tel:+573185700785"><span class="mai-call text-primary"></span> +573185700785</a>
              <span class="divider">|</span>
              <a href="mailto:templet1993@gmail.com"><span class="mai-mail text-primary"></span>templet1993@gmail.com</a>
            </div>
          </div>
          <div class="col-sm-4 text-right text-sm">
            <div class="social-mini-button">
              <a href="https://es-la.facebook.com/"><span class="mai-logo-facebook-f"></span></a>
              <a href="https://twitter.com/?lang=es"><span class="mai-logo-twitter"></span></a>
              <a href="https://dribbble.com/"><span class="mai-logo-dribbble"></span></a>
              <a href="https://www.instagram.com/?hl=es"><span class="mai-logo-instagram"></span></a>
            </div>
          </div>
        </div> <!-- .row -->
      </div> <!-- .container -->
    </div> <!-- .topbar -->

    <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
      <div class="container">
        <a class="navbar-brand" href="#"><span class="text-primary">s.g.f</span>-cronosth</a>

       <!-- 
            se  comenta  barra  de busqueda  hasta  que se pueda  añadir  una  tienda en linea

         <form action="#">
          <div class="input-group input-navbar">
            <div class="input-group-prepend">
              <span class="input-group-text" id="icon-addon1"><span class="mai-search"></span></span>
            </div>
            <input type="text" class="form-control" placeholder="¡ QUE BUSCAS..!" aria-label="Username" aria-describedby="icon-addon1">
          </div>
        </form>


-->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupport" aria-controls="navbarSupport" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupport">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="index">INICIO</a>
            </li>
            <li class="nav-item"  hidden>
              <a class="nav-link" href="vistas/farmacia">FARMACIA</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="vistas/sedes">SEDES</a>
            </li>
            
          
            <li class="nav-item">
              <a class="btn btn-primary ml-lg-3" href="panel/index.php">INICIO SECION</a>
            </li>
          </ul>
        </div> <!-- .navbar-collapse -->
      </div> <!-- .container -->
    </nav>
  </header>
  <div class="page-hero bg-image overlay-dark" style="background-image: url(assets/img/regencia.jpg);">
    <div class="hero-section">
      <div class="container text-center wow zoomIn">
        <span class="subhead">encuentra  tus  medicamentos  al mejor precio</span>
        <h1 class="display-4 typing-effect">Atendemos las 24 Horas</h1>
        <a href="https://api.whatsapp.com/send?phone=+573185700785&text=Hola%20buenas%20noches,%20quisiera%20realizar%20un%20pedido%20de%20los%20siguientes%20medicamentos%20:" target="_blank" class="btn btn-primary">contactar   farmacia</a>
      </div>
    </div>
  </div>


  <div class="bg-light">
    <div class="page-section py-3 mt-md-n5 custom-index">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-4 py-3 py-md-0">
            <div class="card-service wow fadeInUp">
              <div class="circle-shape bg-secondary text-white">
                <span class="mai-chatbubbles-outline"></span>
              </div>
              <p><span>Chat</span> &nbsp; en vivo</p>
            </div>
          </div>
          <div class="col-md-4 py-3 py-md-0">
            <div class="card-service wow fadeInUp">
              <div class="circle-shape bg-primary text-white">
                <span class="mai-shield-checkmark"></span>
              </div>
              <p><span>Medicamentos</span> &nbsp; seguros</p>
            </div>
          </div>
          <div class="col-md-4 py-3 py-md-0">
            <div class="card-service wow fadeInUp">
              <div class="circle-shape bg-accent text-white">
                <span class="mai-basket"></span>
              </div>
              <p><span>Servicio</span>&nbsp; a domicilio</p>
            </div>
          </div>
        </div>
      </div>
    </div> <!-- .page-section -->

    <div class="page-section pb-0">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 py-3 wow fadeInUp">
            <h1>BIENVENIDO A TU <br> FARMACIA VIRTUAL</h1>
            <p class="text-grey mb-4">somos s.g.f cronosth, La unica farmacia en linea con atencion 24 horas al dia durante los 7 dias de la semana y con presencia en mas de 190 municipios </p>
            <a href="tel:+573185700785" class="btn btn-primary"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-forward-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511zm10.761.135a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708-.708L14.293 4H9.5a.5.5 0 0 1 0-1h4.793l-1.647-1.646a.5.5 0 0 1 0-.708z"/>
</svg>&nbsp;&nbsp;Llamar Ahora</a>
          </div>
          <div class="col-lg-6 wow fadeInRight" data-wow-delay="400ms">
            <div class="img-place custom-img-1">
              <img src="assets/img/bg-farmaceutica.jpg" alt="Farmaceutica en la farmacia atendiendo al publico">
            </div>
          </div>
        </div>
      </div>
    </div> <!-- .bg-light -->
  </div> <!-- .bg-light -->

  <div class="page-section">
    <div class="container">
      <h1 class="text-center mb-5 wow fadeInUp">NUESTRO EQUIPO</h1>

      <div class="owl-carousel wow fadeInUp" id="doctorSlideshow">
        <div class="item">
          <div class="card-doctor">
            <div class="header">
              <img src= "assets/img/farmaceuticos/farmaceutica_1.jpg" alt="judith leyton gerente de la farmaceutica sfg cronosth">
              <div class="meta">
                <a href="tel:+57304529951"><span class="mai-call"   id="datos"></span></a>
                <a href="https://api.whatsapp.com/send?phone=+573045299951"><span class="mai-logo-whatsapp"   id="datos"></span></a>
              </div>
            </div>
            <div class="body">
              <p class="text-xl mb-0">judith leyton</p>
              <span class="text-sm text-grey" >fundadora</span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="card-doctor">
            <div class="header">
              <img src="assets/img/farmaceuticos/farmaceutica_2.jpg" alt="gerente general carlos carrasquilla">
              <div class="meta" >
                <a href="tel:+573185700785"><span class="mai-call"   id="datos"></span></a>
                <a href="https://api.whatsapp.com/send?phone=+573185700785"><span class="mai-logo-whatsapp"   id="datos"></span></a>
              </div>
            </div>
            <div class="body">
              <p class="text-xl mb-0">carlos carrasquilla</p>
              <span class="text-sm text-grey">gerente general</span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="card-doctor">
            <div class="header">
              <img src="assets/img/farmaceuticos/farmaceutica_3.jpg" alt="gerente-marketing maira giraldo">
              <div class="meta">
                <a href="tel:+573154032345"><span class="mai-call"   id="datos"></span></a>
                <a href="https://api.whatsapp.com/send?phone=+573154032345"><span class="mai-logo-whatsapp"   id="datos"></span></a>
              </div>
            </div>
            <div class="body">
              <p class="text-xl mb-0">maira giraldo</p>
              <span class="text-sm text-grey">gerente de marketing</span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="card-doctor">
            <div class="header">
              <img src="assets/img/farmaceuticos/farmaceutica_4.jpg" alt="monchito">
              <div class="meta">
                <a href="tel:+573009872345"><span class="mai-call"  id="datos"></span></a>
                <a href="https://api.whatsapp.com/send?phone=+573009872345"><span class="mai-logo-whatsapp"  id="datos"></span></a>
              </div>
            </div>
            <div class="body">
              <p class="text-xl mb-0">ramon valdez</p>
              <span class="text-sm text-grey">gerente bogota</span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="card-doctor">
            <div class="header">
              <img src="assets/img/farmaceuticos/farmaceutica_5.jpg" alt="gildardo esquivel">
              <div class="meta">
                <a href="tel: +573234056789"><span class="mai-call"  id="datos"></span></a>
                <a href="https://api.whatsapp.com/send?phone=+573234056789"><span class="mai-logo-whatsapp"  id="datos"></span></a>
              </div>
            </div>
            <div class="body">
              <p class="text-xl mb-0">gildardo esquivel</p>
              <span class="text-sm text-grey">abogado</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  