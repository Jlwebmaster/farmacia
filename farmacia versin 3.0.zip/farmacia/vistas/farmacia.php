<?php

?>
<!DOCTYPE html>
<html lang="esp">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta http-equiv="X-UA-Compatible" content="ie=edge">

<title>s.g.f cronosth</title>

  <link rel="stylesheet" href="../assets/css/maicons.css">

  <link rel="stylesheet" href="../assets/css/bootstrap.css">

  <link rel="stylesheet" href="../assets/vendor/owl-carousel/css/owl.carousel.css">

  <link rel="stylesheet" href="../assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body>

<style>
  .copy{
    text-align: center;
  }
</style>

  <!-- Back to top button -->
  <div class="back-to-top"></div>

  <header>
    <div class="topbar">
      <div class="container">
        <div class="row">
          <div class="col-sm-8 text-sm">
            <div class="site-info">
              <a href="#"><span class="mai-call text-primary"></span> +573185700785</a>
              <span class="divider">|</span>
              <a href="#"><span class="mai-mail text-primary"></span> templet1993@gmail.com</a>
            </div>
          </div>
          <div class="col-sm-4 text-right text-sm">
          <div class="social-mini-button">
              <a href="https://es-la.facebook.com"><span class="mai-logo-facebook-f"></span></a>
              <a href="https://twitter.com/?lang=es"><span class="mai-logo-twitter"></span></a>
              <a href="https://dribbble.com/"><span class="mai-logo-dribbble"></span></a>
              <a href="https://www.instagram.com/?hl=es"><span class="mai-logo-instagram"></span></a>
            </div>
          </div>
        </div> <!-- .row -->
      </div> <!-- .container -->
    </div> <!-- .topbar -->

    <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
      <div class="container">
        <a class="navbar-brand" href="#"><span class="text-primary">s.g.f</span>-cronosth</a>

        <form action="#">
          <div class="input-group input-navbar">
            <div class="input-group-prepend">
              <span class="input-group-text" id="icon-addon1"><span class="mai-search"></span></span>
            </div>
            <input type="text" class="form-control" placeholder="¡QUE BUSCAS!" aria-label="Username" aria-describedby="icon-addon1">
          </div>
        </form>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupport" aria-controls="navbarSupport" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupport">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="../index">INICIO</a>
            </li>
            
            <li class="nav-item active">
              <a class="nav-link" href="farmacia">FARMACIA</a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" href="sedes">SEDES</a>
            </li>
            
            <li class="nav-item">
              <a class="btn btn-primary ml-lg-3" href="../panel/index.php">INICIO SECION</a>
            </li>
          </ul>
        </div> <!-- .navbar-collapse -->
      </div> <!-- .container -->
    </nav>
  </header>
  <div class="page-hero bg-image overlay-dark" style="background-image: url(../assets/img/farmacia.jpg);">
    <div class="hero-section">
      <div class="container text-center wow zoomIn">
        <span class="subhead">encuentra  tus  medicamentos  al mejor precio</span>
        <h1 class="display-4 typing-effect">Atendemos las 24 Horas</h1>
        <a href="https://api.whatsapp.com/send?phone=+573185700785&text=Hola%20buenas%20noches,%20quisiera%20realizar%20un%20pedido%20de%20los%20siguientes%20medicamentos%20:" target="_blank" class="btn btn-primary">contactar   farmacia</a>
      </div>
    </div>
  </div>
      
       
     

  <div class="page-section bg-light">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-10">

          <div class="row">
            
            <div class="col-md-6 col-lg-4 py-3 wow zoomIn">
              <div class="card-doctor">
                <div class="header">
                  <img src="../assets/img/sedes/sede_1.jpg" alt="bogota">
                  <div class="meta">
                    
                  </div>
                </div>
                <div class="body">
                  <p class="text-xl mb-0">cr 57# 41-19 gaitan </p>
                  <span class="text-sm text-grey">sede principal, bogota</span>
                </div>
              </div>
            </div>
    
            <div class="col-md-6 col-lg-4 py-3 wow zoomIn">
              <div class="card-doctor">
                <div class="header">
                  <img src="../assets/img/sedes/sede_2.jpg" alt="pereira">
                  <div class="meta">
                   
                  </div>
                </div>
                <div class="body">
                  <p class="text-xl mb-0">cr 9 # 21-09 los pinos</p>
                  <span class="text-sm text-grey">sede, pereira</span>
                </div>
              </div>
            </div>
    
            <div class="col-md-6 col-lg-4 py-3 wow zoomIn">
              <div class="card-doctor">
                <div class="header">
                  <img src="../assets/img/sedes/sede_3.jpg" alt="armenia">
                  <div class="meta">
                    
                  </div>
                </div>
                <div class="body">
                  <p class="text-xl mb-0">los camellos # 34-03</p>
                  <span class="text-sm text-grey">sede, armenia </span>
                </div>
              </div>
            </div>
    
            <div class="col-md-6 col-lg-4 py-3 wow zoomIn">
              <div class="card-doctor">
                <div class="header">
                  <img src="../assets/img/sedes/sede_4.jpg" alt="cali">
                  <div class="meta">
                   
                  </div>
                </div>
                <div class="body">
                  <p class="text-xl mb-0">av circunvalar  # 45-06</p>
                  <span class="text-sm text-grey">sede, cali</span>
                </div>
              </div>
            </div>
    
            <div class="col-md-6 col-lg-4 py-3 wow zoomIn">
              <div class="card-doctor">
                <div class="header">
                  <img src="../assets/img/sedes/sede_5.jpg" alt="tunja">
                  <div class="meta">
                    
                  </div>
                </div>
                <div class="body">
                  <p class="text-xl mb-0">hurasandi # 45-06 </p>
                  <span class="text-sm text-grey">sede, tunja</span>
                </div>
              </div>
            </div>
    
            <div class="col-md-6 col-lg-4 py-3 wow zoomIn">
              <div class="card-doctor">
                <div class="header">
                  <img src="../assets/img/sedes/sede_6.jpg" alt="">
                  <div class="meta">
                  </div>
                </div>
                <div class="body">
                  <p class="text-xl mb-0">av uruguay $ 56-09</p>
                  <span class="text-sm text-grey">sede, medellin</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div> <!-- .container -->
  
  
<?php
include_once ("pie.php");
?>
  

  
<script src="../assets/js/jquery-3.5.1.min.js"></script>

<script src="../assets/js/bootstrap.bundle.min.js"></script>

<script src="../assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>

<script src="../assets/vendor/wow/wow.min.js"></script>

<script src="../assets/js/theme.js"></script>
  
</body>
</html>