 <?php
 ?>
 <style>
#redes a{
  color: orangered;
}


.atribucion{

  width: auto;
}

.copy{
  text-align: center;
}

   
 </style>
 <footer class="page-footer">
    <div class="container">
      <div class="row px-md-3">
        <div class="col-sm-6 col-lg-3 py-3"  hidden>
          <h5>empresa</h5>
          <ul class="footer-menu">
            <li><a href="vistas/sedes.php">contactenos</a></li>
            <li><a href="panel/index.php">farmaceuticos</a></li>
            <li><a href="vistas/sedes.php">sedes</a></li>
            <li><a href="vistas/nosotros.php">acerca de nosotros</a></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-3 py-3"  hidden>
          <h5>mas</h5>
          <ul class="footer-menu">
            <li><a href="https://www.masquenegocio.com/2016/05/16/ecommerce-pagina-web/">terminos y condiciones</a></li>
            <li><a href="https://www.wonder.legal/mx/modele/terminos-condiciones">politica de privacidad</a></li>
            <li><a href="https://ads.google.com/intl/es-419_co/getstarted/?subid=co-es-ha-awa-bk-c-cor!o3~CjwKCAjw49qKBhAoEiwAHQVTo03qm0Nb4piUUzGdjink9NjjNUIYbj-Zasx0jMpLjaPz7AaXgL8BAhoCUycQAvD_BwE~78045487869~kwd-94527731~6518825660~435565669404&gclid=CjwKCAjw49qKBhAoEiwAHQVTo03qm0Nb4piUUzGdjink9NjjNUIYbj-Zasx0jMpLjaPz7AaXgL8BAhoCUycQAvD_BwE&gclsrc=aw.ds">anunciar</a></li>
            <li><a href="#">unete como farmaceutico</a></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-3 py-3"  hidden>
          <h5>nuestros socios</h5>
          <ul class="footer-menu">
            <li><a href="https://www.genfar.com.co/">genfar-company</a></li>
            <li><a href="https://empresa.nestle.es/es">nestle-company</a></li>
            <li><a href="https://portal.omnilife.com/">omnilife-company</a></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-3 py-3"  hidden>
          <h5>informacion de  contacto</h5>
          <p class="footer-link mt-2">cll 55 # 21-45 normandia primer sector bogota D.C</p>
          <a href="#" class="footer-link">031-754-434</a>
          <a href="#" class="footer-link">atencionalcliente@farmaceuticadsicol.com</a>

          <h5 class="mt-3">Redes Sociales</h5>
          <div class="footer-sosmed mt-3"  id="redes">
            <a href="https://es-la.facebook.com/" target="_blank"><span class="mai-logo-facebook-f"></span></a>
            <a href="https://twitter.com/?lang=es" target="_blank"><span class="mai-logo-twitter"></span></a>
            <a href="https://myaccount.google.com" target="_blank"><span class="mai-logo-google-plus-g"></span></a>
            <a href="https://www.instagram.com/?hl=es" target="_blank"><span class="mai-logo-instagram"></span></a>
            <a href="https://co.linkedin.com/" target="_blank"><span class="mai-logo-linkedin"></span></a>
          </div>
        </div>
      </div>

      <hr>
  <div  class="atribucion">
      <p id="copyright"   class="copy">Copyright &nbsp; &copy; 2022 <a href="https://www.jlwebmaster.com.co" target="_blank">  &nbsp; &nbsp;CRONOSTH COMPANY</a>&nbsp;&nbsp; todos los derechos reservados</p>
    </div>
  </footer>
  
<script src="assets/js/jquery-3.5.1.min.js"></script>

<script src="assets/js/bootstrap.bundle.min.js"></script>

<script src="assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>

<script src="assets/vendor/wow/wow.min.js"></script>

<script src="assets/js/theme.js"></script>
  
</body>
</html>