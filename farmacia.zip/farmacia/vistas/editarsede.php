<?php




if(!($_GET['nombresed']));{
    

include_once"../vistas/conetdb.php";


$productopro=$_GET['nombresed'];
$sentencia=$base->prepare("SELECT * FROM sede WHERE nombresed= ?;");
$sentencia->execute([$productopro]);
$nuevoprod=$sentencia->fetch(PDO::FETCH_OBJ);
 //print_r( $nuevoprod);



}


    ?>

    <!DOCTYPE html>
    <html lang="esp">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>farmaceuticadsicol</title>
        <link rel="stylesheet" href="assets/css/maicons.css">

  <link rel="stylesheet" href="../assets/css/bootstrap.css">

  <link rel="stylesheet" href="../assets/vendor/owl-carousel/css/owl.carousel.css">

  <link rel="stylesheet" href="../assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="../assets/css/theme.css">
    </head>
   <body>
       <style>
           h3{
               text-align: center;
           }

           .form-horizontal{
            width: 100%;
  max-width: 600px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
           }
       </style>
  
   
    <h3 >editar sede</h3>
			<form class="form-horizontal" method="POST" action="../validaciones/editarsed.php" autocomplete="off">
            <table class="table">


            <tr>
  <th scope="col"  >nombre sede:</th>
      <th scope="col">
						<input type="text" class="form-control" id="tnombre" name="txnombre"  value="<?php echo $nuevoprod->nombresed  ?>"  required ></th>
            </tr>
<tr>

                        <th scope="col"  >ciudad:</th>
      <th scope="col">
						<input type="text" class="form-control" id="tnombre" name="txciudad"  value="<?php echo $nuevoprod->ciudadsed ?>"  required ></th>
					
</tr>
<tr>

                        <th scope="col"  >direcion:</th>
      <th scope="col">
						<input type="text" class="form-control" id="tnombre" name="txdirecion"  value="<?php echo $nuevoprod->direcionsed  ?>"  required ></th>
					
</tr>
					
<tr>

                        <th scope="col"  >telefono:</th>
      <th scope="col">
						<input type="number" class="form-control" id="tnombre" name="txtelefono"  value="<?php echo $nuevoprod->telefonosed  ?>"  required ></th>
					
</tr>
			

<tr>

                        <th scope="col"  >correo:</th>
      <th scope="col">
						<input type="email" class="form-control" id="tnombre" name="txcorreo"  value="<?php echo $nuevoprod->correosed  ?>"  required ></th>
					
</tr>
					

<tr>

                        <th scope="col"  >cantidad empleados:</th>
      <th scope="col">
						<input type="number" class="form-control" id="tnombre" name="txempleados"  value="<?php echo $nuevoprod->cantidadEmpleadossed  ?>"  required ></th>
					
</tr>


<tr>
<th scope="col">
<a href="listarsede.php" class="btn btn-default">Regresar</a>
   <!-- <input type="hidden"  name="oculto">-->
   <input type="hidden"  name="idsede"   value="<?php echo $nuevoprod->idsede ?>  ">
   <input type="hidden"  name="administrador"   value="<?php echo $nuevoprod->administradorid ?>  ">
    <input type="submit" value="GUARDAR CAMBIOS">


</th>

</tr>
					
					
					


     

          




				</div>
			</form>

           
            
</div>
</body>
    </html>







