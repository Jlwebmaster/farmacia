<?php
?>
<!DOCTYPE html>
<html lang="esp">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta http-equiv="X-UA-Compatible" content="ie=edge">

<title>farmaceutica adsicol</title>

  <link rel="stylesheet" href="assets/css/maicons.css">

  <link rel="stylesheet" href="assets/css/bootstrap.css">

  <link rel="stylesheet" href="assets/vendor/owl-carousel/css/owl.carousel.css">

  <link rel="stylesheet" href="assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="assets/css/theme.css">
 
  
  
</head>
<body>

  <!-- Back to top button -->
 

  <header>
    <div class="topbar">
      <div class="container">
        <div class="row">
          <div class="col-sm-8 text-sm">
            <div class="site-info">
              <a href="#"><span class="mai-call text-primary"></span> +573005034567</a>
              <span class="divider">|</span>
              <a href="#"><span class="mai-mail text-primary"></span>gerencia@farmaceuticadsicol.com</a>
            </div>
          </div>
          <div class="col-sm-4 text-right text-sm">
            <div class="social-mini-button">
              <a href="https://es-la.facebook.com/"><span class="mai-logo-facebook-f"></span></a>
              <a href="https://twitter.com/?lang=es"><span class="mai-logo-twitter"></span></a>
              <a href="https://dribbble.com/"><span class="mai-logo-dribbble"></span></a>
              <a href="https://www.instagram.com/?hl=es"><span class="mai-logo-instagram"></span></a>
            </div>
          </div>
        </div> <!-- .row -->
      </div> <!-- .container -->
    </div> <!-- .topbar -->

    <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
      <div class="container">
        <a class="navbar-brand" href="#"><span class="text-primary">farmaceutica</span>-adsicol</a>

        <form action="#">
          <div class="input-group input-navbar">
            <div class="input-group-prepend">
              <span class="input-group-text" id="icon-addon1"><span class="mai-search"></span></span>
            </div>
            <input type="text" class="form-control" placeholder="¡ QUE BUSCAS..!" aria-label="Username" aria-describedby="icon-addon1">
          </div>
        </form>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupport" aria-controls="navbarSupport" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupport">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">INICIO</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="vistas/nosotros.php"> NOSOTROS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="vistas/sedes.php">SEDES</a>
            </li>
            
          
            <li class="nav-item">
              <a class="btn btn-primary ml-lg-3" href="panel/index.php">INICIO SECION</a>
            </li>
          </ul>
        </div> <!-- .navbar-collapse -->
      </div> <!-- .container -->
    </nav>
  </header>
  <div class="page-hero bg-image overlay-dark" style="background-image: url(assets/img/cabezera.jpg);">
    <div class="hero-section">
      <div class="container text-center wow zoomIn">
        <span class="subhead">te atendemos las 24 horas los 7 dias </span>
        <h1 class="display-4">calidad y experiencia  a su servicio</h1>
        <a href="https://api.whatsapp.com/send?phone=+573185700785" class="btn btn-primary">contactar un farmaceutico</a>
      </div>
    </div>
  </div>


  <div class="bg-light">
    <div class="page-section py-3 mt-md-n5 custom-index">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-4 py-3 py-md-0">
            <div class="card-service wow fadeInUp">
              <div class="circle-shape bg-secondary text-white">
                <span class="mai-chatbubbles-outline"></span>
              </div>
              <p><span>Chatear</span> &nbsp; con farmaceutico</p>
            </div>
          </div>
          <div class="col-md-4 py-3 py-md-0">
            <div class="card-service wow fadeInUp">
              <div class="circle-shape bg-primary text-white">
                <span class="mai-shield-checkmark"></span>
              </div>
              <p><span>sientase</span> &nbsp; seguro</p>
            </div>
          </div>
          <div class="col-md-4 py-3 py-md-0">
            <div class="card-service wow fadeInUp">
              <div class="circle-shape bg-accent text-white">
                <span class="mai-basket"></span>
              </div>
              <p><span>compre</span>&nbsp; sus medicinas</p>
            </div>
          </div>
        </div>
      </div>
    </div> <!-- .page-section -->

    <div class="page-section pb-0">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 py-3 wow fadeInUp">
            <h1>BIENVENID@ A NUESTRO  <br>CENTRO DE ATENCION VIRTUAL</h1>
            <p class="text-grey mb-4">somos farmaceutica adsicol, una  empresa colombiana  con sede en cada ciudad y municipio de los 32 departamentos del soberano estado colombiano... atendemos  las 24 horas del dia los 7 dias de la semana  atravez de este portal web donde podras hacer los pedidos de tus  mediicamentos y se te entregaran en la puerta de tu casa  por uno de nuestros colaboradoresl.... gracias por elegirnos como tu farmacia favorita</p>
            <a href="nosotros.html" class="btn btn-primary">leer mas</a>
          </div>
          <div class="col-lg-6 wow fadeInRight" data-wow-delay="400ms">
            <div class="img-place custom-img-1">
              <img src="assets/img/bg-farmaceutica.jpg" alt="">
            </div>
          </div>
        </div>
      </div>
    </div> <!-- .bg-light -->
  </div> <!-- .bg-light -->

  <div class="page-section">
    <div class="container">
      <h1 class="text-center mb-5 wow fadeInUp">nuestro equipo</h1>

      <div class="owl-carousel wow fadeInUp" id="doctorSlideshow">
        <div class="item">
          <div class="card-doctor">
            <div class="header">
              <img src= "assets/img/farmaceuticos/farmaceutica_1.jpg" alt="">
              <div class="meta">
                <a href="tel:+57304529951"><span class="mai-call"></span></a>
                <a href="https://api.whatsapp.com/send?phone=+573045299951"><span class="mai-logo-whatsapp"></span></a>
              </div>
            </div>
            <div class="body">
              <p class="text-xl mb-0">judith leyton</p>
              <span class="text-sm text-grey">fundadora</span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="card-doctor">
            <div class="header">
              <img src="assets/img/farmaceuticos/farmaceutica_2.jpg" alt="gerente">
              <div class="meta">
                <a href="tel:+573185700785"><span class="mai-call"></span></a>
                <a href="https://api.whatsapp.com/send?phone=+573185700785"><span class="mai-logo-whatsapp"></span></a>
              </div>
            </div>
            <div class="body">
              <p class="text-xl mb-0">carlos carrasquilla</p>
              <span class="text-sm text-grey">gerente general</span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="card-doctor">
            <div class="header">
              <img src="assets/img/farmaceuticos/farmaceutica_3.jpg" alt="gerente-marketing">
              <div class="meta">
                <a href="tel:+573154032345"><span class="mai-call"></span></a>
                <a href="https://api.whatsapp.com/send?phone=+573154032345"><span class="mai-logo-whatsapp"></span></a>
              </div>
            </div>
            <div class="body">
              <p class="text-xl mb-0">maira giraldo</p>
              <span class="text-sm text-grey">gerente de marketing</span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="card-doctor">
            <div class="header">
              <img src="assets/img/farmaceuticos/farmaceutica_4.jpg" alt="monchito">
              <div class="meta">
                <a href="tel:+573009872345"><span class="mai-call"></span></a>
                <a href="https://api.whatsapp.com/send?phone=+573009872345"><span class="mai-logo-whatsapp"></span></a>
              </div>
            </div>
            <div class="body">
              <p class="text-xl mb-0">ramon valdez</p>
              <span class="text-sm text-grey">gerente bogota</span>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="card-doctor">
            <div class="header">
              <img src="assets/img/farmaceuticos/farmaceutica_5.jpg" alt="">
              <div class="meta">
                <a href="tel: +573234056789"><span class="mai-call"></span></a>
                <a href="https://api.whatsapp.com/send?phone=+573234056789"><span class="mai-logo-whatsapp"></span></a>
              </div>
            </div>
            <div class="body">
              <p class="text-xl mb-0">gildardo esquivel</p>
              <span class="text-sm text-grey">abogado</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

   <!-- .page-section -->

  

  <div class="page-section banner-home bg-image" style="background-image: url(../assets/img/banner-pattern.svg);">
    <div class="container py-5 py-lg-0">
      <div class="row align-items-center">
        <div class="col-lg-4 wow zoomIn">
          <div class="img-banner d-none d-lg-block">
            <img src="../assets/img/mobile_app.png" alt="">
          </div>
        </div>
        <div class="col-lg-8 wow fadeInRight">
          <h1 class="font-weight-normal mb-3">somos una farmacia  amiga</h1>
          <a href="#"><img src="assets/img/google_play.svg" alt=""></a>
          <a href="#" class="ml-2"><img src="assets/img/app_store.svg" alt=""></a>
        </div>
      </div>
    </div>
  </div> 